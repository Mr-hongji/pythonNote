# -*- coding:utf-8 -*-
''';'''

def test1():
    print('Moudle1.test1..')
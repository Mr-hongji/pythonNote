# -*- coding:utf-8 -*-
''''''

def test2():
    print('moudle2.test2...')